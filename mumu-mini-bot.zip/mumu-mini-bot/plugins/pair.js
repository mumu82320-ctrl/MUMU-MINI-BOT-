'use strict';

const config = require('../config');

// Rate-limit: one code per phone per 60 seconds
const cooldowns = new Map();

module.exports = {
    commands:    ['pair', 'getcode', 'paircode'],
    description: 'Generate a WhatsApp pair code to link your number to the bot',
    permission:  'public',
    group:       true,
    private:     true,

    run: async (sock, message, args, { sender, reply, prefix, contextInfo }) => {
        const rawPhone = (args[0] || '').replace(/\D/g, '').trim();

        // ── No number provided: show usage ──────────────────────────────────
        if (!rawPhone) {
            return reply(
`🔑 *Pair Code Linker*

Generate a pairing code for your WhatsApp number.

*Usage:*
  \`${prefix}pair <phone>\`

*Example:*
  \`${prefix}pair 263776719736\`

📌 Include your country code (no \`+\` or spaces).

After running the command, you'll receive an 8-character code.

*How to use the code:*
1. Open WhatsApp on your phone
2. Tap ⋮ *Menu* → *Linked Devices*
3. Tap *Link a Device*
4. Tap *Link with phone number instead*
5. Enter your number, then enter the code`
            );
        }

        // ── Rate limit: 60s per phone ────────────────────────────────────────
        const now = Date.now();
        const lastReq = cooldowns.get(rawPhone) || 0;
        const remaining = Math.ceil((60_000 - (now - lastReq)) / 1000);
        if (now - lastReq < 60_000) {
            return reply(`⏳ A code was recently generated for this number.\nPlease wait *${remaining}s* before requesting a new one.`);
        }

        // ── Validate phone length ────────────────────────────────────────────
        if (rawPhone.length < 7 || rawPhone.length > 15) {
            return reply(`❌ *Invalid phone number.*\nMake sure you include the country code.\n\nExample: \`${prefix}pair 263776719736\``);
        }

        // ── Notify user: code is being generated ─────────────────────────────
        const dmJid = sender.includes('@g.us')
            ? (message.key.participant || message.key.remoteJid)
            : sender;
        const userJid = dmJid.includes('@g.us') ? dmJid : dmJid;

        try {
            await sock.sendMessage(userJid, {
                text: `⏳ *Generating pair code for* +${rawPhone}...\nPlease wait a moment.`,
                contextInfo
            }, { quoted: message });
        } catch { /* group → DM fallback below */ }

        // ── Request the pairing code ─────────────────────────────────────────
        let code;
        try {
            code = await sock.requestPairingCode(rawPhone);
        } catch (err) {
            const msg = err.message || '';
            let reason = '❌ Failed to generate pair code.';
            if (/not registered|not found|invalid/i.test(msg))
                reason = `❌ Number *+${rawPhone}* is not registered on WhatsApp.`;
            else if (/rate|limit|too many/i.test(msg))
                reason = `⏳ Too many code requests. Please wait a minute and try again.`;

            return sock.sendMessage(userJid, { text: reason, contextInfo }, { quoted: message });
        }

        cooldowns.set(rawPhone, Date.now());

        // Format as XXXX-XXXX
        const formatted = code.match(/.{1,4}/g)?.join('-') || code;

        const codeMsg =
`🔑 *Your WhatsApp Pair Code*

╔══════════════════╗
║   *${formatted}*   ║
╚══════════════════╝

📱 *Number:* +${rawPhone}
⏱️ *Valid for:* ~60 seconds

*Steps to link:*
1. Open WhatsApp → ⋮ Menu → *Linked Devices*
2. Tap *Link a Device*
3. Tap *Link with phone number instead*
4. Enter your number then enter the code above

> _Powered by Mumu Mini Bot_`;

        // Send to DM if in group, otherwise reply in chat
        try {
            const targetJid = message.key.remoteJid.endsWith('@g.us')
                ? (message.key.participant || sender).split('@')[0] + '@s.whatsapp.net'
                : sender;

            await sock.sendMessage(targetJid, { text: codeMsg, contextInfo }, { quoted: message });

            if (message.key.remoteJid.endsWith('@g.us')) {
                await reply(`✅ Pair code sent to your DM, @${rawPhone} — check your private messages!`);
            }
        } catch (err) {
            await reply(codeMsg);
        }
    }
};
