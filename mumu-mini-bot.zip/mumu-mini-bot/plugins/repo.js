'use strict';

const axios  = require('axios');
const moment = require('moment-timezone');

const REPO_URL    = 'https://github.com/Mumu Mini BotB/silva-md-bot';
const WEBSITE_URL = 'https://whatsapp.com/channel/0029VbCKsZSFcow7ucYvJc0J';
const WA_CHANNEL  = 'https://whatsapp.com/channel/0029VbCKsZSFcow7ucYvJc0J';
const SUPPORT_URL = 'https://whatsapp.com/channel/0029VbCKsZSFcow7ucYvJc0J';

module.exports = {
    commands:    ['repo', 'repository', 'github'],
    description: 'Show Mumu Mini Bot repository info',
    permission:  'public',
    group:       true,
    private:     true,

    run: async (sock, message, args, ctx) => {
        const { contextInfo } = ctx;
        const jid = message.key.remoteJid;

        let data = null;
        try {
            const res = await axios.get(
                'https://api.github.com/repos/Mumu Mini BotB/silva-md-bot',
                { timeout: 10000 }
            );
            data = res.data;
        } catch { /* use fallback */ }

        const caption = data
            ? `*✨ MUMU MINI BOT — INFO*\n\n` +
              `📦 *Bot:* Mumu Mini Bot\n` +
              `📝 *About:* ${data.description || 'WhatsApp MD Bot'}\n\n` +
              `⭐ *Stars:* ${data.stargazers_count.toLocaleString()}\n` +
              `🍴 *Forks:* ${data.forks_count.toLocaleString()}\n` +
              `💻 *Language:* ${data.language || 'JavaScript'}\n` +
              `📦 *Size:* ${(data.size / 1024).toFixed(1)} MB\n` +
              `📜 *License:* ${data.license?.name || 'MIT'}\n` +
              `⚠️ *Open Issues:* ${data.open_issues}\n` +
              `🕒 *Updated:* ${moment(data.updated_at).fromNow()}\n\n` +
              `📢 *Channel:* ${WA_CHANNEL}\n` +
              `💬 *Support:* ${SUPPORT_URL}\n\n` +
              `⚡ _Powered by Mumu Mini Bot_`
            : `*✨ MUMU MINI BOT*\n\n` +
              `📦 *Bot:* Mumu Mini Bot\n` +
              `💻 *Language:* JavaScript\n` +
              `📜 *License:* MIT\n\n` +
              `📢 *Channel:* ${WA_CHANNEL}\n` +
              `💬 *Support:* ${SUPPORT_URL}\n\n` +
              `⚡ _Powered by Mumu Mini Bot_`;

        const imgUrl = 'https://files.catbox.moe/5uli5p.jpeg';

        await sock.sendMessage(jid, {
            image:   { url: imgUrl },
            caption,
            contextInfo: {
                ...contextInfo,
                externalAdReply: {
                    title:                 'Mumu Mini Bot',
                    body:                  'Join our WhatsApp Channel!',
                    thumbnailUrl:          imgUrl,
                    sourceUrl:             WA_CHANNEL,
                    mediaType:             1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: message });
    }
};
